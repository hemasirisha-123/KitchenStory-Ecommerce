import { Kitchen } from './kitchen';

describe('Kitchen', () => {
  it('should create an instance', () => {
    expect(new Kitchen()).toBeTruthy();
  });
});