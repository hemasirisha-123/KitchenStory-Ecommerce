import { Component, OnInit } from '@angular/core';
import { KitchenService } from '../kitchen.service';
import { Kitchen } from '../kitchen';

@Component({
  selector: 'app-search-kitchen',
  templateUrl: './search-kitchen.component.html',
  styleUrls: ['./search-kitchen.component.css']
})
export class SearchKitchenComponent implements OnInit {
  kitchenCost:number;
  data:any;
  Kitchens:Kitchen[];
  constructor(private kitchenService:KitchenService) { }

  public getKitchenByCost():void{
    this.kitchenService.getKitchenByCost(this.kitchenCost).subscribe( data => {
      this.data=data;
      console.log(this.data);
    })
  };

  ngOnInit() {
  }

}
