import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchKitchenComponent } from './search-kitchen.component';

describe('SearchKitchenComponent', () => {
  let component: SearchKitchenComponent;
  let fixture: ComponentFixture<SearchKitchenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchKitchenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchKitchenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
