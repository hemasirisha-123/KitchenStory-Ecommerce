import { Component, OnInit } from '@angular/core';
import { Kitchen } from '../kitchen';
import { KitchenService } from '../kitchen.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-kitchen',
  templateUrl: './create-kitchen.component.html',
  styleUrls: ['./create-kitchen.component.css']
})
export class CreateKitchenComponent implements OnInit {

  public kitchen:Kitchen;
  constructor(private kitchenService:KitchenService,private router:Router) { 
    this.kitchen=new Kitchen();
  }

  public createKitchen():void{
    this.kitchenService.createKitchen(this.kitchen).subscribe(res=>{
      this.kitchen=new Kitchen();
      this.router.navigate(['/kitchensList'])
    });
  }

  ngOnInit() {

  }

}
