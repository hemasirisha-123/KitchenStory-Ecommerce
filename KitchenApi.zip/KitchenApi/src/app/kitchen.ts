export class Kitchen {
    id: number;
    name: string;
    cost: number;
    category: string;
    avatar: string;
}
