import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KitchensListComponent } from './kitchens-list.component';

describe('KitchensListComponent', () => {
  let component: KitchensListComponent;
  let fixture: ComponentFixture<KitchensListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KitchensListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KitchensListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
