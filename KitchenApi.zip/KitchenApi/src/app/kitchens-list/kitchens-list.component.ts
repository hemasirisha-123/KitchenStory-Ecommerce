import { Component, OnInit } from '@angular/core';
import { Kitchen } from '../kitchen';
import { KitchenService } from '../kitchen.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-kitchens-list',
  templateUrl: './kitchens-list.component.html',
  styleUrls: ['./kitchens-list.component.css']
})
export class KitchensListComponent implements OnInit {

  public kitchensList:Kitchen[];

  constructor(private kitchenService:KitchenService,private router:Router) { }
    public selectItem():void{
      this.router.navigate(['/kitchensList'])
    }
  ngOnInit() {
    this.kitchenService.getAllKitchens().subscribe(res=>{
      this.kitchensList=res;
    });
   
  }

}
