import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateKitchenComponent } from './create-kitchen/create-kitchen.component';
//import { UpdateAnimalComponent } from './update-animal/update-animal.component';
import { DeleteKitchenComponent } from './delete-kitchen/delete-kitchen.component';
import { SearchKitchenComponent } from './search-kitchen/search-kitchen.component';
import { KitchensListComponent } from './kitchens-list/kitchens-list.component';
const routes: Routes = [
  {path:'createKitchen',component:CreateKitchenComponent},
 // {path:'updateAnimal',component:UpdateAnimalComponent},
  {path:'deleteKitchen',component:DeleteKitchenComponent},
  {path:'searchKitchen',component:SearchKitchenComponent},
  {path:'kitchensList',component:KitchensListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
