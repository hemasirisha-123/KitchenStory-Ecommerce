import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteKitchenComponent } from './delete-kitchen.component';

describe('DeleteKitchenComponent', () => {
  let component: DeleteKitchenComponent;
  let fixture: ComponentFixture<DeleteKitchenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteKitchenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteKitchenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
