import { Component, OnInit } from '@angular/core';
import { KitchenService } from '../kitchen.service';
import { Kitchen } from '../kitchen';

@Component({
  selector: 'app-delete-kitchen',
  templateUrl: './delete-kitchen.component.html',
  styleUrls: ['./delete-kitchen.component.css']
})
export class DeleteKitchenComponent implements OnInit {
  kitchenIdModel:number;
  Kitchens:Kitchen[]=[];
  constructor(private kitchenService:KitchenService) { }

  public deleteKitchenById():void{
    this.kitchenService.deleteKitchenById(this.kitchenIdModel).subscribe( data => {
      this.Kitchens = this.Kitchens.splice(this.kitchenIdModel-1,1);
    })
};
  ngOnInit() {
  }

}
