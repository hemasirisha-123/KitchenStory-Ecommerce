import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Kitchen } from './kitchen';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KitchenService {
  deleteKitchen(kitchen: Kitchen[]) {
    throw new Error("Method not implemented.");
  }
  private url:string;
  constructor(private http:HttpClient) {
    this.url='http://localhost:9200/kitchen';
   }
   public createKitchen(kitchen:Kitchen):Observable<Kitchen>{
    return this.http.post<Kitchen>(this.url,kitchen);
  }
  public deleteKitchenById(id:number): Observable<Kitchen> {
    return this.http.get<Kitchen>(this.url + id);
  }
  public getKitchenByCost(cost:number): Observable<Kitchen> {
    return this.http.get<Kitchen>(this.url + cost);
  }
  public getAllKitchens():Observable<Kitchen[]>{
    return this.http.get<Kitchen[]>(this.url+"s");
  }
}
